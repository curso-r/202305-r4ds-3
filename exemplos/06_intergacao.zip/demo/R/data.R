#' Partidas do Brasileirão
#'
#' Partidas do Brasileirão até 2022 coletadas por William Amorim.
#'
#' @format Uma tabela composta por:
#' \describe{
#'   \item{temporada}{Temporada}
#'   \item{data}{Data do jogo}
#' }
#'
#' @source <https://github.com/williamorim/brasileirao>
"partidas_brasileirao"
