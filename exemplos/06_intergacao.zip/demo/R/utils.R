utils::globalVariables(c(
  "ano", "continente", "expectativa_de_vida", "n_vitorias",
  "partidas_brasileirao", "populacao", "quem_ganhou", "temporada"
))
