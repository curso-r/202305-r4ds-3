library(tidyverse)

partidas_brasileirao <- read_csv2("data-raw/dados_brutos/partidas_brasileirao_bruto.csv")

usethis::use_data(partidas_brasileirao, overwrite = TRUE)
